dtk-make-bossert
===

- `make`: Führe alles aus
- `article`: Erstelle nur den Artikel
- `minimize`: Erstelle eine komprimierte PDF
- `count.colorpages`: Zähle Seiten mit Farbe und erstelle eine CSV
- `zip`: Erstelle eine zip-Datei mit den notwendigen Dateien plus PDF 
